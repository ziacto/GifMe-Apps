##GIFME
A chrome extension that makes saving, sharing and organizing gifs easier.

<a href='https://chrome.google.com/webstore/detail/gif-me/aeblbmdigihnlnnmoejhagmpihfjdaab' target='_blank'>Download Here</a>


##Notes
This code cannot be reused or modified. This should be only used as an example and reference.

&copy; 2013 Drew Dahlman