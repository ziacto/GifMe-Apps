/////////////////////////////////////////////////////
//
//	GIFME
//	Author: Drew Dahlman ( www.drewdahlman.com )
//	Version: 3.0
//	Date: 08.19.2013
//	File: detail.js
//	
//	Copyright 2013 Gifme.io
//
/////////////////////////////////////////////////////

(function() {
	detail = function(data) {
		var self = this;

		self.data = data;
		
		self.create = function(){

		}

		self.destroy = function(){

		}
		return self;
	}
})()